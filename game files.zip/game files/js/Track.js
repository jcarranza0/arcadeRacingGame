const TRACK_W = 40;
const TRACK_H = 40;
const TRACK_GAP = 2;
const TRACK_COLS = 20;
const TRACK_ROWS = 15;

var theStart = [101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,
				121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,
				141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,
				161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,
				181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,
				201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,
				221,3  ,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,3  ,240,
				241,2  ,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,2  ,260,
				261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,
				281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,
				301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,
				321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,
				341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,
				361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,
				381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400];
				

var theArena =  [4,   4,  4, 17,  9,  9, 9, 9, 9, 9, 9, 9, 9, 9,  9, 9, 16,  4,  4,  4,
				 4,   4, 17, 14,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 12, 16,  4,  4,
				 4,  17, 14,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0,  0, 12, 16,  4,
				 17, 14,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0,  0,  0, 12, 16,
				 6,   0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0,  0,  0,  0,  7,
				 6,   0,  0,  0,  0, 13, 8, 8, 8, 8, 8, 8, 8, 8, 15, 0,  0,  0,  0,  7,
				 6,   5,  2,  2,  5,  7, 4, 4, 4, 4, 4, 4, 4, 4,  6, 0,  0,  0,  0,  7,
				 21, 11, 11, 11, 11, 20, 4, 4, 4, 4, 4, 4, 4, 4,  6, 0,  0,  0,  0,  7,
				 6,   5,  3,  3,  5,  7, 4, 4, 4, 4, 4, 4, 4, 4,  6, 0,  0,  0,  0,  7,
				 6,   0,  0,  0,  0,  7, 4, 4, 4, 4, 4, 4, 4, 4,  6, 0,  0,  0,  0,  7,
				 6,   0,  0,  0,  0, 12, 9, 9, 9, 9, 9, 9, 9, 9, 14, 0,  0,  0,  0,  7,
				 19, 15,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0,  0,  0, 13, 18,
				 4,  19, 15,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0,  0, 13, 18,  4,
				 4,   4, 19, 15,  0,  0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 13, 18,  4,  4,
				 4,   4,  4, 19,  8,  8, 8, 8, 8, 8, 8, 8, 8, 8,  8, 8, 18,  4,  4,  4];

var slamZone =  [17,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9, 16,
				  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  7,
				  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  7,
				  6,  0,  0, 13,  8, 11, 11, 11, 15,  0,  0, 13, 11, 11, 11,  8, 15,  0,  0,  7,
				  6,  0,  0,  7,  4,  0,  0,  0,  4,  0,  0,  4,  0,  0,  0,  4,  6,  0,  0,  7,
				  6,  0,  0,  7,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  4,  6,  0,  0,  7,
				  6,  0,  0,  7,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  4,  6,  0,  0,  7,
				  6,  2,  0,  7,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  4,  6,  0,  2,  7,
				  6, 11, 11, 23,  4,  0,  4, 11, 11, 11, 11, 11, 11,  4,  0,  4, 24, 11, 11,  7,
				  6,  0,  0,  0,  0,  0, 10,  4,  4,  4,  4,  4,  4, 10,  0,  0,  0,  0,  0,  7,
				  6,  0,  0,  0,  0,  0, 10,  4,  5,  3,  3,  5,  4, 10,  0,  0,  0,  0,  0,  7,
				  6,  0,  0,  0,  0,  0, 10,  4, 10,  0,  0, 10,  4, 10,  0,  0,  0,  0,  0,  7,
				  6,  0,  4, 11, 11, 11,  4,  4,  5,  0,  0,  5,  4,  4, 11, 11, 11,  4,  0,  7,
				  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  7,
				 19,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8, 18];

var oldLevel =  [4, 4, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4,
				 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
				 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
				 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1,
				 1, 0, 0, 0, 1, 1, 1, 4, 4, 4, 4, 1, 1, 1, 1, 1, 1, 0, 0, 1,
				 1, 0, 0, 1, 1, 0, 0, 1, 4, 4, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 1, 4, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 5, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 5, 0, 0, 0, 5, 0, 0, 1, 0, 0, 1, 0, 0, 1,
				 1, 2, 2, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 5, 0, 0, 1,
				 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
				 0, 3, 0, 0, 0, 0, 1, 4, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1,
				 0, 3, 0, 0, 0, 0, 1, 4, 4, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1,
				 1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4, 4, 1, 1, 1, 1, 1, 4];
				 
var proLevel =  [4, 4, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4,
				 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
				 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
				 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1,
				 1, 0, 0, 0, 1, 1, 1, 4, 4, 4, 4, 1, 1, 1, 1, 1, 1, 0, 0, 1,
				 1, 0, 0, 1, 1, 0, 0, 1, 4, 4, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 1, 0, 0, 0, 1, 4, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 0, 3, 1, 0, 0, 5, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 0, 0, 0, 3, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,
				 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 5, 0, 0, 1, 0, 0, 1, 0, 0, 1,
				 1, 2, 2, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 5, 0, 0, 1,
				 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
				 1, 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1,
				 1, 4, 4, 1, 0, 0, 0, 0, 4, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1,
				 1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4, 4, 1, 1, 1, 1, 1, 4];
				 
var extremeLevel = [ 13, 8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8,  8, 15,
					 7, 25, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 25, 29, 29, 29, 29, 29,  6, 
					 7, 30, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 30, 26, 26, 26, 26, 26,  6,
					 7, 30, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 30, 26, 26, 26, 26, 26,  6,
					 7, 30, 26, 26, 25, 29, 29, 29, 29, 29, 25, 26, 26, 30, 26, 26, 25, 26, 26,  6, 
					 7, 30, 26, 26, 30, 26, 26, 26, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 30, 26, 26, 26, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26,  6, 
					 7, 30, 26, 26, 30, 26, 26, 25, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 30, 26, 26, 30, 26, 26, 26, 26, 26, 30, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 30, 26, 26, 30, 26, 26, 26, 26, 26, 30, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 30, 26, 26, 25, 29, 29, 29, 29, 29, 25, 26, 26, 30, 26, 26,  6,
					 7, 30,  2,  2, 30, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 30, 26, 26,  6,
					 7, 30, 26, 26, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 30,  3,  3,  6,
					 7, 30, 26, 26,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9,  9, 14];
					 
var loopLevel = [31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31,
				 31, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 31, 
				 31, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 31, 
				 31, 32, 32,  5, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35, 35,  5, 32, 32, 31,
				 31, 32, 32, 34, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 34, 32, 32, 31, 
				 31, 32, 32, 34, 32, 32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 34, 32, 32, 31,
				 31, 32, 32, 34, 32, 32,  5, 35, 35, 35, 35, 35, 35,  5, 32, 32, 34, 32, 32, 31, 
				 31, 32, 32, 34, 32, 32, 34, 32, 32, 33, 33, 33,  3, 31, 32, 32, 34, 32, 32, 31, 
				 31, 32, 32, 34, 32, 32, 34, 32, 32,  5, 35, 35, 35,  5, 32, 32, 34, 32, 32, 31, 
				 31, 32, 32, 34, 32, 32, 34, 33, 33, 33, 33, 33, 33, 33, 32, 32, 34, 32, 32, 31,
				 31, 32, 32, 34, 32, 32, 34, 33, 33, 33, 33, 33, 33, 33, 32, 32, 34, 32, 32, 31, 
				 31, 32, 32, 34, 32, 32,  5, 35, 35, 35, 35, 35, 35, 35, 35, 35,  5, 32, 32, 31, 
				 31,  2,  2, 34, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 32, 32, 31,
				 31, 32, 32, 34, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 32, 32, 31,
				 31, 32, 32, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31];			 


var levelList = [theStart, theArena, slamZone, oldLevel, proLevel, extremeLevel, loopLevel];
var levelNow = 0;
var trackGrid = [];

//cover
const TITLE_SCREEN = 101;
const TitlteScreen_2 = 102;
const TitlteScreen_3 = 103;
const TitlteScreen_4 = 104;
const TitlteScreen_5 = 105;
const TitlteScreen_6 = 106;
const TitlteScreen_7 = 107;
const TitlteScreen_8 = 108;
const TitlteScreen_9 = 109;
const TitlteScreen_10 = 110;
const TitlteScreen_11 = 111;
const TitlteScreen_12 = 112;
const TitlteScreen_13 = 113;
const TitlteScreen_14 = 114;
const TitlteScreen_15 = 115;
const TitlteScreen_16 = 116;
const TitlteScreen_17 = 117;
const TitlteScreen_18 = 118;
const TitlteScreen_19 = 119;
const TitlteScreen_20 = 120;
const TitlteScreen_21 = 121;
const TitlteScreen_22 = 122;
const TitlteScreen_23 = 123;
const TitlteScreen_24 = 124;
const TitlteScreen_25 = 125;
const TitlteScreen_26 = 126;
const TitlteScreen_27 = 127;
const TitlteScreen_28 = 128;
const TitlteScreen_29 = 129;
const TitlteScreen_30 = 130;
const TitlteScreen_31 = 131;
const TitlteScreen_32 = 132;
const TitlteScreen_33 = 133;
const TitlteScreen_34 = 134;
const TitlteScreen_35 = 135;
const TitlteScreen_36 = 136;
const TitlteScreen_37 = 137;
const TitlteScreen_38 = 138;
const TitlteScreen_39 = 139;
const TitlteScreen_40 = 140;
const TitlteScreen_41 = 141;
const TitlteScreen_42 = 142;
const TitlteScreen_43 = 143;
const TitlteScreen_44 = 144;
const TitlteScreen_45 = 145;
const TitlteScreen_46 = 146;
const TitlteScreen_47 = 147;
const TitlteScreen_48 = 148;
const TitlteScreen_49 = 149;
const TitlteScreen_50 = 150;
const TitlteScreen_51 = 151;
const TitlteScreen_52 = 152;
const TitlteScreen_53 = 153;
const TitlteScreen_54 = 154;
const TitlteScreen_55 = 155;
const TitlteScreen_56 = 156;
const TitlteScreen_57 = 157;
const TitlteScreen_58 = 158;
const TitlteScreen_59 = 159;
const TitlteScreen_60 = 160;
const TitlteScreen_61 = 161;
const TitlteScreen_62 = 162;
const TitlteScreen_63 = 163;
const TitlteScreen_64 = 164;
const TitlteScreen_65 = 165;
const TitlteScreen_66 = 166;
const TitlteScreen_67 = 167;
const TitlteScreen_68 = 168;
const TitlteScreen_69 = 169;
const TitlteScreen_70 = 170;
const TitlteScreen_71 = 171;
const TitlteScreen_72 = 172;
const TitlteScreen_73 = 173;
const TitlteScreen_74 = 174;
const TitlteScreen_75 = 175;
const TitlteScreen_76 = 176;
const TitlteScreen_77 = 177;
const TitlteScreen_78 = 178;
const TitlteScreen_79 = 179;
const TitlteScreen_80 = 180;
const TitlteScreen_81 = 181;
const TitlteScreen_82 = 182;
const TitlteScreen_83 = 183;
const TitlteScreen_84 = 184;
const TitlteScreen_85 = 185;
const TitlteScreen_86 = 186;
const TitlteScreen_87 = 187;
const TitlteScreen_88 = 188;
const TitlteScreen_89 = 189;
const TitlteScreen_90 = 190;
const TitlteScreen_91 = 191;
const TitlteScreen_92 = 192;
const TitlteScreen_93 = 193;
const TitlteScreen_94 = 194;
const TitlteScreen_95 = 195;
const TitlteScreen_96 = 196;
const TitlteScreen_97 = 197;
const TitlteScreen_98 = 198;
const TitlteScreen_99 = 199;
const TitlteScreen_100 = 200;
const TitlteScreen_101 = 201;
const TitlteScreen_102 = 202;
const TitlteScreen_103 = 203;
const TitlteScreen_104 = 204;
const TitlteScreen_105 = 205;
const TitlteScreen_106 = 206;
const TitlteScreen_107 = 207;
const TitlteScreen_108 = 208;
const TitlteScreen_109 = 209;
const TitlteScreen_110 = 210;
const TitlteScreen_111 = 211;
const TitlteScreen_112 = 212;
const TitlteScreen_113 = 213;
const TitlteScreen_114 = 214;
const TitlteScreen_115 = 215;
const TitlteScreen_116 = 216;
const TitlteScreen_117 = 217;
const TitlteScreen_118 = 218;
const TitlteScreen_119 = 219;
const TitlteScreen_120 = 220;
const TitlteScreen_121 = 221;
const TitlteScreen_122 = 222;
const TitlteScreen_123 = 223;
const TitlteScreen_124 = 224;
const TitlteScreen_125 = 225;
const TitlteScreen_126 = 226;
const TitlteScreen_127 = 227;
const TitlteScreen_128 = 228;
const TitlteScreen_129 = 229;
const TitlteScreen_130 = 230;
const TitlteScreen_131 = 231;
const TitlteScreen_132 = 232;
const TitlteScreen_133 = 233;
const TitlteScreen_134 = 234;
const TitlteScreen_135 = 235;
const TitlteScreen_136 = 236;
const TitlteScreen_137 = 237;
const TitlteScreen_138 = 238;
const TitlteScreen_139 = 239;
const TitlteScreen_140 = 240;
const TitlteScreen_141 = 241;
const TitlteScreen_142 = 242;
const TitlteScreen_143 = 243;
const TitlteScreen_144 = 244;
const TitlteScreen_145 = 245;
const TitlteScreen_146 = 246;
const TitlteScreen_147 = 247;
const TitlteScreen_148 = 248;
const TitlteScreen_149 = 249;
const TitlteScreen_150 = 250;
const TitlteScreen_151 = 251;
const TitlteScreen_152 = 252;
const TitlteScreen_153 = 253;
const TitlteScreen_154 = 254;
const TitlteScreen_155 = 255;
const TitlteScreen_156 = 256;
const TitlteScreen_157 = 257;
const TitlteScreen_158 = 258;
const TitlteScreen_159 = 259;
const TitlteScreen_160 = 260;
const TitlteScreen_161 = 261;
const TitlteScreen_162 = 262;
const TitlteScreen_163 = 263;
const TitlteScreen_164 = 264;
const TitlteScreen_165 = 265;
const TitlteScreen_166 = 266;
const TitlteScreen_167 = 267;
const TitlteScreen_168 = 268;
const TitlteScreen_169 = 269;
const TitlteScreen_170 = 270;
const TitlteScreen_171 = 271;
const TitlteScreen_172 = 272;
const TitlteScreen_173 = 273;
const TitlteScreen_174 = 274;
const TitlteScreen_175 = 275;
const TitlteScreen_176 = 276;
const TitlteScreen_177 = 277;
const TitlteScreen_178 = 278;
const TitlteScreen_179 = 279;
const TitlteScreen_180 = 280;
const TitlteScreen_181 = 281;
const TitlteScreen_182 = 282;
const TitlteScreen_183 = 283;
const TitlteScreen_184 = 284;
const TitlteScreen_185 = 285;
const TitlteScreen_186 = 286;
const TitlteScreen_187 = 287;
const TitlteScreen_188 = 288;
const TitlteScreen_189 = 289;
const TitlteScreen_190 = 290;
const TitlteScreen_191 = 291;
const TitlteScreen_192 = 292;
const TitlteScreen_193 = 293;
const TitlteScreen_194 = 294;
const TitlteScreen_195 = 295;
const TitlteScreen_196 = 296;
const TitlteScreen_197 = 297;
const TitlteScreen_198 = 298;
const TitlteScreen_199 = 299;
const TitlteScreen_200 = 300;
const TitlteScreen_201 = 301;
const TitlteScreen_202 = 302;
const TitlteScreen_203 = 303;
const TitlteScreen_204 = 304;
const TitlteScreen_205 = 305;
const TitlteScreen_206 = 306;
const TitlteScreen_207 = 307;
const TitlteScreen_208 = 308;
const TitlteScreen_209 = 309;
const TitlteScreen_210 = 310;
const TitlteScreen_211 = 311;
const TitlteScreen_212 = 312;
const TitlteScreen_213 = 313;
const TitlteScreen_214 = 314;
const TitlteScreen_215 = 315;
const TitlteScreen_216 = 316;
const TitlteScreen_217 = 317;
const TitlteScreen_218 = 318;
const TitlteScreen_219 = 319;
const TitlteScreen_220 = 320;
const TitlteScreen_221 = 321;
const TitlteScreen_222 = 322;
const TitlteScreen_223 = 323;
const TitlteScreen_224 = 324;
const TitlteScreen_225 = 325;
const TitlteScreen_226 = 326;
const TitlteScreen_227 = 327;
const TitlteScreen_228 = 328;
const TitlteScreen_229 = 329;
const TitlteScreen_230 = 330;
const TitlteScreen_231 = 331;
const TitlteScreen_232 = 332;
const TitlteScreen_233 = 333;
const TitlteScreen_234 = 334;
const TitlteScreen_235 = 335;
const TitlteScreen_236 = 336;
const TitlteScreen_237 = 337;
const TitlteScreen_238 = 338;
const TitlteScreen_239 = 339;
const TitlteScreen_240 = 340;
const TitlteScreen_241 = 341;
const TitlteScreen_242 = 342;
const TitlteScreen_243 = 343;
const TitlteScreen_244 = 344;
const TitlteScreen_245 = 345;
const TitlteScreen_246 = 346;
const TitlteScreen_247 = 347;
const TitlteScreen_248 = 348;
const TitlteScreen_249 = 349;
const TitlteScreen_250 = 350;
const TitlteScreen_251 = 351;
const TitlteScreen_252 = 352;
const TitlteScreen_253 = 353;
const TitlteScreen_254 = 354;
const TitlteScreen_255 = 355;
const TitlteScreen_256 = 356;
const TitlteScreen_257 = 357;
const TitlteScreen_258 = 358;
const TitlteScreen_259 = 359;
const TitlteScreen_260 = 360;
const TitlteScreen_261 = 361;
const TitlteScreen_262 = 362;
const TitlteScreen_263 = 363;
const TitlteScreen_264 = 364;
const TitlteScreen_265 = 365;
const TitlteScreen_266 = 366;
const TitlteScreen_267 = 367;
const TitlteScreen_268 = 368;
const TitlteScreen_269 = 369;
const TitlteScreen_270 = 370;
const TitlteScreen_271 = 371;
const TitlteScreen_272 = 372;
const TitlteScreen_273 = 373;
const TitlteScreen_274 = 374;
const TitlteScreen_275 = 375;
const TitlteScreen_276 = 376;
const TitlteScreen_277 = 377;
const TitlteScreen_278 = 378;
const TitlteScreen_279 = 379;
const TitlteScreen_280 = 380;
const TitlteScreen_281 = 381;
const TitlteScreen_282 = 382;
const TitlteScreen_283 = 383;
const TitlteScreen_284 = 384;
const TitlteScreen_285 = 385;
const TitlteScreen_286 = 386;
const TitlteScreen_287 = 387;
const TitlteScreen_288 = 388;
const TitlteScreen_289 = 389;
const TitlteScreen_290 = 390;
const TitlteScreen_291 = 391;
const TitlteScreen_292 = 392;
const TitlteScreen_293 = 393;
const TitlteScreen_294 = 394;
const TitlteScreen_295 = 395;
const TitlteScreen_296 = 396;
const TitlteScreen_297 = 397;
const TitlteScreen_298 = 398;
const TitlteScreen_299 = 399;
const TitlteScreen_300 = 400;



const TRACK_ROAD = 0;
const TRACK_WALL = 1;
const TRACK_PLAYERSTART = 2;
const TRACK_GOAL = 3;
const TRACK_TREE = 4;
const TRACK_FLAG = 5;
const TRACK_WALLR = 6;
const TRACK_WALLL = 7;
const TRACK_WALLT = 8;
const TRACK_WALLB = 9;
const TRACK_WALLLR = 10;
const TRACK_WALLTB = 11;
const TRACK_WALLLB = 12;
const TRACK_WALLLT = 13;
const TRACK_WALLRB = 14;
const TRACK_WALLRT = 15;
const TRACK_WALLCBL = 16;
const TRACK_WALLCBR = 17;
const TRACK_WALLCTL = 18;
const TRACK_WALLCTR = 19;
const TRACK_WALLCBTL = 20;
const TRACK_WALLCBTR = 21;
const TRACK_WALLRBCLT = 22;
const TRACK_WALLBCTL = 23;
const TRACK_WALLBCTR = 24;
const CORNER_BLUE = 25;
const GRAYTRACK_ONE = 26;
const GRAYTRACK_TWO = 27; 
const GRAYTRACKT_THREE = 28;
const HSTRBLUE_TRACK = 29;
const VSTRBLUE_TRACK = 30;
const ABSTRACT_WALL = 31;
const era = 32;
const liney = 33;
const VFENCE_WALL = 34;
const HFENCE_WALL = 35;





function returnTileTypeAtColRow(col, row) {
	if(col >= 0 && col < TRACK_COLS &&
		row >= 0 && row < TRACK_ROWS) {
		 var trackIndexUnderCoord = rowColToArrayIndex(col, row);
		 return trackGrid[trackIndexUnderCoord];
	} else {
		return TRACK_WALL;
	}
}

function carTrackHandling(whichCar) {
	var carTrackCol = Math.floor(whichCar.x / TRACK_W);
	var carTrackRow = Math.floor(whichCar.y / TRACK_H);
	var trackIndexUnderCar = rowColToArrayIndex(carTrackCol, carTrackRow);

	if(carTrackCol >= 0 && carTrackCol < TRACK_COLS &&
		carTrackRow >= 0 && carTrackRow < TRACK_ROWS) {
		var tileHere = returnTileTypeAtColRow( carTrackCol,carTrackRow );

		if(tileHere == TRACK_GOAL) {
			console.log(whichCar.name + " WINS!");
			//alert(whichCar.name+ " Wins!"); //sometimes it bugs out
			nextLevel();
		} else if(tileHere != TRACK_ROAD && tileHere != GRAYTRACK_ONE && tileHere != era && tileHere != liney) {
			// next two lines added to fix a bug
			// undoes the car movement which got it onto the wall
			whichCar.x -= Math.cos(whichCar.ang) * whichCar.speed;
			whichCar.y -= Math.sin(whichCar.ang) * whichCar.speed;
		
			whichCar.speed *= -0.5;
		
		} // end of track found
	} // end of valid col and row
} // end of carTrackHandling func

function rowColToArrayIndex(col, row) {
	return col + TRACK_COLS * row;
}

function drawTracks() {

	var arrayIndex = 0;
	var drawTileX = 0;
	var drawTileY = 0;
	for(var eachRow=0;eachRow<TRACK_ROWS;eachRow++) {
		for(var eachCol=0;eachCol<TRACK_COLS;eachCol++) {

			var arrayIndex = rowColToArrayIndex(eachCol, eachRow); 
			var tileKindHere = trackGrid[arrayIndex];
			var useImg = trackPics[tileKindHere];

			canvasContext.drawImage(useImg,drawTileX,drawTileY);
			drawTileX += TRACK_W;
			arrayIndex++;
		} // end of for each col
		drawTileY += TRACK_H;
		drawTileX = 0;
	} // end of for each row

} // end of drawTracks func